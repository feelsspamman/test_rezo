# Tachiyomi-Rezo-Scans

Unofficial Tachiyomi extension for [Rezo Scans](https://rezoscans.com).

**Version:** 1.4.21  
**Package:** eu.kanade.tachiyomi.extension.en.rezoscans

## APK
Find the APK in `/release/tachiyomi-en.rezoscans-v1.4.21.apk`.

## Source Info
- Base URL: https://rezoscans.org
- Language: English (`en`)
- NSFW: No

## About
This repository contains the unofficial Tachiyomi extension for Rezo Scans, providing manga in English sourced from the above site.